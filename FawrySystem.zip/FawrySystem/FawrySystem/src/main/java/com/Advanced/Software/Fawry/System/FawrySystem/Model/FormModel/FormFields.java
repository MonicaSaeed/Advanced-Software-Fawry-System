package com.Advanced.Software.Fawry.System.FawrySystem.Model.FormModel;


public interface FormFields {
	
	public String getFieldType() ;
	public String getFieldName() ;
	public void setField(String text);
	public String getFinalValue();
	
}
