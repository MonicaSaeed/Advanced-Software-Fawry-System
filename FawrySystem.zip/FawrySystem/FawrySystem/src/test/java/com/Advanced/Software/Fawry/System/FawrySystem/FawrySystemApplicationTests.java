package com.Advanced.Software.Fawry.System.FawrySystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FawrySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
